exports = module.exports = require('./lib/functions');

exports.BMP24 = require('./lib/BMP24');
exports.Font = require('./lib/font');